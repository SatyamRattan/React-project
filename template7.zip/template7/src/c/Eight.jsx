import React from "react";

const Eightpage = () =>{
    return(
        <div className="group-8">
      <div className="background-3" />
      <div className="design-6">
        <img
          className="place-your-image-here-double-click-to-edit-6"
          src="images/place_your_image_here_dou_2.jpg"
          alt=""
          width={474}
          height={473}
        />
        <img
          className="shape-17"
          src="images/shape_6.png"
          alt=""
          width={716}
          height={997}
        />
        <div className="line-5" />
        <div className="text-11 group">
          <p className="title-13">
            &nbsp;walking in nature
            <br />
            as a recreational
            <br />
            activity
          </p>
          <div className="col-6">
            <p className="title-14">
              Mountaineering
              <br />
              ice climbing
            </p>
            <p className="subtitle-7">2. activities</p>
            <p className="body-text-13">
              Kundalini is the most classic yoga. Its origin is in the Raya Yoga
              of Patanjali and other classical texts such as <br />
              Bhagavad Gita and Hatha Yoga <br />
              Pradipika.
            </p>
            <p className="text-12">
              17 modules
              <br />
              divided into 5 weekends
            </p>
            <div className="row-11 group">
              <p className="date-3">
                Start
                <br />
                April 15
                <br />
                20.00 hs
              </p>
              <p className="price-2">
                Price
                <br />
                $900
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    )
}
export default Eightpage