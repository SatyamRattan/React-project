import React from "react";

const Thirdpage = () =>{
    return(
        <div className="l-constrained" id="c">
      <div className="row-5 group">
        <img
          className="shape-5"
          src="images/shape_25.png"
          alt=""
          width={23}
          height={93}
        />
        <div className="col-23">
          <p className="title-2">
            Hiking And Camping <strong className="fw700">Classes</strong>
          </p>
          <div className="shape-6" />
          <div className="second">

         
          <div className="row-9 match-height group">
            <div className="col-16">
              <img
                className="place-your-design-here-double-click-to-edit"
                src="images/place_your_design_here_do_3.png"
                alt=""
                width={137}
                height={137}
              />
              <p className="subtitle">activities</p>
            </div>
            <div className="col-17">
              <img
                className="place-your-design-here-double-click-to-edit-2"
                src="images/place_your_design_here_do.png"
                alt=""
                width={137}
                height={137}
              />
              <p className="subtitle-2">hiking</p>
            </div>
            <div className="col-18">
              <img
                className="place-your-design-here-double-click-to-edit-3"
                src="images/place_your_design_here_do_2.png"
                alt=""
                width={137}
                height={137}
              />
              <p className="subtitle-3">mountains</p>
            </div>
          </div>
          <div className="row-6 group">
            <p className="body-text-2">
              Lorem ipsum dolor sit amet consectetur adipiscing, elit molestie
              posuere
            </p>
            <p className="body-text-3">
              Lorem ipsum dolor sit amet consectetur adipiscing, elit molestie
              posuere
            </p>
            <p className="body-text-4">
              Lorem ipsum dolor sit amet consectetur adipiscing, elit molestie
              posuere
            </p>
          </div>
          </div>
        </div>
      </div>
      <img
        className="shape-7"
        src="images/shape_25.png"
        alt=""
        width={23}
        height={93}
      />
    </div>
    )
}
export default Thirdpage
