import React from "react";

const Sixthpage = () =>{
    return(
        <div className="group-6">
      <div className="shape-holder-5">
        <img
          className="shape-13"
          src="images/shape_13.png"
          alt=""
          width={419}
          height={236}
        />
      </div>
      <div className="shape-holder-6">
        <div className="shape-holder-7">
          <div className="text-8">
            <p className="title-8">
              &nbsp;walking in nature
              <br />
              as a recreational
              <br />
              activity
            </p>
            <p className="subtitle-6">.activities</p>
            <p className="body-text-9">
              Lorem ipsum dolor sit amet
              <br />
              consectetur adip.
            </p>
          </div>
        </div>
      </div>
    </div>
    )
}
export default Sixthpage;
