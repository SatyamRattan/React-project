import React from "react";

const Ninthpage = () =>{
    return(
        <div className="image-4">
        <div className="col-4">
          <div className="l-constrained-3">
            <p className="body-text-14">
              The asanas purify our body and keep it healthy, making it a suitable
              vehicle for the soul.
            </p>
            <img
              className="shape-18"
              src="images/shape_3.png"
              alt=""
              width={92}
              height={76}
            />
            <div className="button-3">see more</div>
          </div>
        </div>
      </div>
    )
}
export default Ninthpage