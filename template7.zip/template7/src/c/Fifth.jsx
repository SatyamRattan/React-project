import React from "react";

const Fifthpage = () =>{
    return(
        <div className="design-4 group" id="o">
      <img
        className="shape-10"
        src="images/shape_18.png"
        alt=""
        width={23}
        height={93}
      />
      <div className="wrapper-2">
        <img
          className="place-your-image-here-double-click-to-edit-2"
          src="images/place_your_image_here_dou_7.jpg"
          alt=""
          width={537}
          height={647}
        />
        <div className="shape-holder-4">
          <img
            className="shape-11"
            src="images/shape_18.png"
            alt=""
            width={23}
            height={93}
          />
        </div>
        <img
          className="place-your-design-here-double-click-to-edit-4"
          src="images/place_your_design_here_do.png"
          alt=""
          width={137}
          height={137}
        />
        <img
          className="place-your-design-here-double-click-to-edit-5"
          src="images/place_your_design_here_do_2.png"
          alt=""
          width={137}
          height={137}
        />
        <img
          className="place-your-design-here-double-click-to-edit-6"
          src="images/place_your_design_here_do_3.png"
          alt=""
          width={137}
          height={137}
        />
        <div className="shape-12" />
        <div className="text-7 group">
          <div className="col-2">
            <p className="title-6">
              HOW TO RECOVER FROM
              <br />A HIKE
            </p>
            <p className="body-text-6">
              - Lorem ipsum
              <br />- Dolor sit amet consectetur - Adipiscing elit aptent -
              Torquent, interdum
            </p>
            <p className="body-text-7">
              - Fusce etiam augue - Dignissim at euismod - Libero montes,
              <br />- Adipiscing elit aptent - Torquent, interdum
            </p>
            <p className="body-text-8">
              - Libero montes,
              <br />- Adipiscing elit aptent
              <br />- Torquent, interdum
            </p>
          </div>
          <p className="title-7">
            Make Sure Your
            <br />
            Gear Fits
          </p>
        </div>
      </div>
    </div>
    )
}
export default Fifthpage