import React from "react";

const Seventhpage = () =>{
    return(
        <div className="group-7">
        <div className="text-10">
         
          <div className="image-3 group">
          <p className="title-9">
            places to visit
            <br />
            in autumn
          </p>
            <img
              className="place-your-image-here-double-click-to-edit-3"
              src="images/place_your_image_here_dou_5.jpg"
              alt=""
              width={285}
              height={273}
            />
            <img
              className="place-your-image-here-double-click-to-edit-4"
              src="images/place_your_image_here_dou_4.jpg"
              alt=""
              width={274}
              height={283}
            />
            <img
              className="place-your-image-here-double-click-to-edit-5"
              src="images/place_your_image_here_dou_3.jpg"
              alt=""
              width={280}
              height={278}
            />
          </div>
          <div className="row-3 group">
            <div className="mountain">
              <p className="title-10">Mountain Loop</p>
              <p className="body-text-10">
                Lorem ipsum sit amet,
                <br />
                consectetur &nbsp;adipisicing...
              </p>
              <div className="line-2" />
              <p className="location">
                <strong className="fw700">Location </strong>0.3 miles.
              </p>
            </div>
            <div className="national-park">
              <p className="title-11">National Park</p>
              <p className="body-text-11">
                Lorem ipsum dolor amet,
                <br />
                consectetur &nbsp;adipisicing...
              </p>
              <div className="line-3" />
              <p className="location-2">
                <strong className="fw700">Location</strong> 0.2 miles.
              </p>
            </div>
            <div className="canyon">
              <p className="title-12">Canyon Trail</p>
              <p className="body-text-12">
                Lorem ipsum dolor sit
                <br />
                consectetur &nbsp;adipisicing...
              </p>
              <div className="line-4" />
              <p className="location-3">
                <strong className="fw700">Location </strong>0.6 miles.
              </p>
            </div>
          </div>
        </div>
        <div className="design-5">
          <div className="l-constrained-4">
            <div className="row group">
              <img
                className="shape-14"
                src="images/shape_8.png"
                alt=""
                width={6}
                height={25}
              />
              <img
                className="shape-15"
                src="images/shape_8.png"
                alt=""
                width={6}
                height={25}
              />
              <img
                className="shape-16"
                src="images/shape_8.png"
                alt=""
                width={6}
                height={25}
              />
            </div>
            <div className="button-2">see more</div>
          </div>
        </div>
      </div>
    )
}
export default Seventhpage