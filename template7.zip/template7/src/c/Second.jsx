import React, { useState } from 'react';

const Secondpage = () =>{
   
  const [menuVisible, setMenuVisible] = useState(false);
  const toggleMenu = () => {
      setMenuVisible(!menuVisible);
    };
    return(
        <div className="design">
        <div className="image">
          <img
            className="shape"
            src="images/shape_28.png"
            alt=""
            width={520}
            height={292}
          />
        </div>
        <img
          className="shape-2"
          src="images/shape_29.png"
          alt=""
          width={389}
          height={219}
        />
        <img
          className="shape-3"
          src="images/shape_30.png"
          alt=""
          width={364}
          height={205}
        />
        <div className="shape-holder">
          <div className="shape-holder-2">
            <div className="col-3">
              <div className="toolbar group">
                <img
                  className="place-your-logo-here-double-click-to-edit"
                  src="images/place_your_logo_here_doub.png"
                  alt=""
                  width={219}
                  height={61}
                />
                 <button className="menu-btn" onClick={toggleMenu} >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
          {/*!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.*/}
          <path fill='white' d="M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z" />
        </svg>
      </button>
                <ul className={`nav-list group ${menuVisible ? 'show' : ''}`}>
               
                
               <a href="">
    <p className="home">Home</p>
</a>
<a href="#c">
    <p className="class">Class</p>
</a>
<a href="#p">
    <p className="promo">Promo</p>
</a>
<a href="#o">
    <p className="text">Online Class</p>
</a>
<a href="#cc">
    <p className="contact">Contact</p>
</a>
</ul>

              </div>
              <div className="row-4 group">
                <img
                  className="shape-4"
                  src="images/shape_34.png"
                  alt=""
                  width={8}
                  height={30}
                />
                <div className="text-2">
                  <p className="title">
                    <span className="text-style">Discover your next Hike</span>
                    <br />
                    <span className="text-style-2">Discover your</span>
                    <br />
                    <span className="text-style-3">next hike</span>
                  </p>
                  <p className="body-text">
                    Lorem ipsum dolor sit amet,
                    <br />
                    consectetur
                    <br />
                    adipiscing elit, sed do.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    )
}

export default Secondpage